#include "mypushbutton.h"

MyPushButton::MyPushButton(const QString &text, QWidget *parent)
    :QPushButton(text, parent)
{
    connect(this, &QPushButton::clicked, this, &MyPushButton::onClicked);
}

void MyPushButton::onClicked()
{
    emit clicked(this);
}

