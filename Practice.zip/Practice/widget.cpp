#include "widget.h"
#include<QPushButton>
#include<QDebug>
#include<QLineEdit>
#include "mypushbutton.h"
//#include"metaCharacter.h"
#include <exception>
#include <QMessageBox>
#include<QColor>
#include<QColorDialog>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    //界面编辑
    setWindowTitle("表达式计算器");


    setStyleSheet("QPushButton{"
                  "background-color:white;"
                  "color: black;"
                  "width:93px;"
                  "height:48px;"
                  "font-family:微软雅黑;"//字体样式
                  "font: bold 20px;"//字体加粗及大小
                  "border-radius: 0px;"
                  "border: 0px groove gray;"
                  "border-style: outset;}"



                  "QPushButton:hover{"   //鼠标停留
                  "color: black;"
                  "border: 2px groove gray;"
                  "background:rgb(218,221,218);}"

                  "QPushButton:pressed,QPushButton:disabled{"
                  "color: white;"
                  "background-color:rgb(0, 0, 0);"
                  "border-style: inset; }");
    centralWidget=new QWidget(this);
    mainLayout=new QGridLayout(centralWidget);



    //将创建的Buttons以循环方式建立按钮并且导入
    buttonsLayout=new QGridLayout();
    for(int i=0;i<BUTTONS.size();i++)//按行循环，一共7行
    {
        QVector<string> row=BUTTONS.at(i);//提取出按钮每一行
        for(int j=0;j<row.size();j++)
        {
            const string &name=row.at(j);//将BUTTONS的名字提取出来

            if(!(name.empty()))
            {

                MyPushButton *pushButton = new MyPushButton(QString::fromStdString(name));
                buttons.push_back(pushButton);  //保存至按钮数组
                connect(pushButton,&MyPushButton::clicked,this,&Widget::setInputText);
                buttonsLayout->setSpacing(3);
                //此处if语句 控制颜色
                if(i<3 ||j>2)
                {
                    pushButton-> setStyleSheet("QPushButton{"
                                               "background-color:rgb(247,247,247);"
                                                "font: 15px;"//字体加粗及大小
                                               "color: black;}"

                                               "QPushButton:hover{"   //鼠标停留
                                               "color: black;"
                                               "border: 2px groove gray;"
                                               "background:rgb(218,221,218);}"

                                               "QPushButton:pressed,QPushButton:disabled{"
                                               "color: white;"
                                               "background-color:rgb(0, 0, 0);}"
                                               );
                    buttonsLayout->addWidget(pushButton, i, j);
                }
                else
                {
                    buttonsLayout->addWidget(pushButton, i, j);
                }
            }
        }
    }
    //功能键"C"，"BACKSPACE"，"EQUAL"的显示与功能实现
    Equal=new QPushButton(QString::fromStdString(EQUAL));
    C_Button=new QPushButton(QString::fromStdString(C));
    BackSpace=new QPushButton(QString::fromStdString(BACKSPACE));

    //功能键样式选择
    Equal-> setStyleSheet("QPushButton{"
                          "background-color:rgb(143,191,229);"
                        "font: 15px;"//字体加粗及大小
                          "color: black;}"

                          "QPushButton:hover{"   //鼠标停留
                          "color: black;"
                          "border: 2px groove gray;"
                          "background:rgb(69,153,219);}"

                          "QPushButton:pressed,QPushButton:disabled{"
                          "color: white;"
                          "background-color:rgb(0, 0, 0);"
                          "border-style: inset; }");
    BackSpace-> setStyleSheet("QPushButton{"
                              "background-color:rgb(247,247,247);"
                              "font: 15px;"//字体加粗及大小
                              "color: black;}"

                              "QPushButton:hover{"   //鼠标停留
                              "color: black;"
                              "border: 2px groove gray;"
                              "background:rgb(218,221,218);}"

                              "QPushButton:pressed,QPushButton:disabled{"
                              "color: white;"
                              "background-color:rgb(0, 0, 0);"
                              "border-style: inset; }");

    C_Button-> setStyleSheet("QPushButton{"
                             "background-color:rgb(247,247,247);"
                            "font: 15px;"//字体加粗及大小
                             "color: black;}"

                             "QPushButton:hover{"   //鼠标停留
                             "color: black;"
                             "border: 2px groove gray;"
                             "background:rgb(218,221,218);}"

                             "QPushButton:pressed,QPushButton:disabled{"
                             "color: white;"
                             "background-color:rgb(0, 0, 0);"
                             "border-style: inset; }");


    //将按钮放在指定位置
    buttonsLayout->addWidget(Equal,6,3);
    buttonsLayout->addWidget(C_Button,1,2);
    buttonsLayout->addWidget(BackSpace,1,3);

    //将按钮连接指定功能函数
    connect(Equal,&QPushButton::clicked,this,&Widget::onEqualClicked);
    connect(C_Button,&QPushButton::clicked,this,&Widget::onClearClicked);
    connect(BackSpace,&QPushButton::clicked,this,&Widget::onBackspaceClicked);






    hLayout=new QHBoxLayout(centralWidget);

    for(int i=0;i<FUNCTION_BUTTONS.size();i++)
    {
        const  string &name=FUNCTION_BUTTONS.at(i);
        QPushButton *btn=new QPushButton(QString::fromStdString(name));
        btn->setStyleSheet("QPushButton{"
                       "background:transparent;"
                       "color: black;"
                       "width:20px;"
                       "height:38px;"
                       "font-family:微软雅黑;"//字体样式
                       "font:12px;"//字体加粗及大小
                       "border-radius: 0px;"
                       "border: 0px groove gray;"
                       "border-style: outset;}"



                       "QPushButton:hover{"   //鼠标停留
                       "color: black;"
                       "border: 2px groove gray;"
                       "background:rgb(218,221,218);}"

                       "QPushButton:pressed,QPushButton:disabled{"
                       "color: white;"
                       "background-color:rgb(0, 0, 0);"
                       "border-style: inset; }");
        buttons.push_back(btn);
        hLayout->addWidget(btn);



    }

    inputText=new QLineEdit("0");   //表达式输入框
    resultText=new QLineEdit("");  //计算结果显示框
    inputText->setAlignment(Qt::AlignRight);
    resultText->setAlignment(Qt::AlignRight);
    inputText->setStyleSheet("QLineEdit{height: 50px;"
                             "width:20px;"
                             "border:none;"
                             "font-size: 60px;"
                             "background:transparent;}"
                             );
    resultText->setStyleSheet("QLineEdit{"
                              "height: 50px;"
                                "width:20px;"
                              "font-size: 30px;"
                              "border:none;"
                              "background:transparent;}"
                              );
    inputText->setReadOnly(true);
    resultText->setReadOnly(true);

    mainLayout->addWidget(inputText,0,0,1,4);
    mainLayout->addWidget(resultText,1,2,1,2);

    mainLayout->addLayout(hLayout,2,0,1,4);
    mainLayout->addLayout(buttonsLayout,3,0,6,4);


    resize(399,477+20);
    setMinimumSize(399,477+20);

//            resize(mainLayout->sizeHint());
//            qDebug()<<mainLayout->sizeHint();
    //封装进栈容器
    stackedWidget=new QStackedWidget(this);
    stackedWidget->addWidget(centralWidget);
    stackedWidget->move(0,20);

    comboBox=new QComboBox(this);

    comboBox->addItem("标准");
    comboBox->setItemIcon(0,QIcon(":/comboBox_png/resourse/caculator.png"));
    comboBox->addItem("科学");
    comboBox->setItemIcon(1,QIcon(":/comboBox_png/resourse/secience.png"));
    comboBox->addItem("绘图");
    comboBox->setItemIcon(2,QIcon(":/comboBox_png/resourse/paint.png"));
    comboBox->addItem("程序员");
    comboBox->setItemIcon(3,QIcon(":/comboBox_png/resourse/chengxuyuan.png"));
    comboBox->addItem("日期转换");
    comboBox->setItemIcon(4,QIcon(":/comboBox_png/resourse/date.png"));


    label=new QLabel("标准");
    label->setParent(this);
    label->move(150,5);

    //    connect(ui->comboBox,static_cast<void(QComboBox::*)(int index)>(&QComboBox::currentIndexChanged),ui->stackedWidget,&QStackedWidget::setCurrentIndex);
    connect(comboBox,static_cast<void(QComboBox::*)(int index)>(&QComboBox::currentIndexChanged),stackedWidget,&QStackedWidget::setCurrentIndex);

    //标签空间Label跟随功能显示
    connect(comboBox,&QComboBox::currentTextChanged,label,&QLabel::setText);


    //显示栈窗口第二页，便于验证
    QLabel *label2=new QLabel("标准");
    label2->setParent(this);
    label2->move(100,200);
    stackedWidget->addWidget(label2);

    //显示栈窗口，调色板
    //        QColor color=QColorDialog::getColor();
    //stackedWidget->addWidget(color);
    //        qDebug()<<"Red="<<color.red()<<"Green="<<color.green()<<"Blue"<<color.blue();
    //       <<color.hue()<<color.Sat<<color.val();
}

string Widget::transformStdExpression(QString expression)
{
    expression = expression.replace("×", "*").replace("÷", "/").replace("√", "#").replace("°", "`");
    return expression.toStdString();
}

void Widget::setInputText(MyPushButton *pushButton)
{
    QString symbol = pushButton->text();


    /*
     * 未计算完成,还在输入中,将输入的字符直接添加至表达式输入框文本后
     */
    if(calcFinished==false)
    {
        inputText->setText(inputText->text()+pushButton->text());
    }
    /*
     * 已经计算完成,准备开始下一次计算
     * 根据输入的内容,若为数字/括号/前置运算符/可省略第一个操作数的中置运算符,则直接将输入显示在输入框中
     */
    else
    {
        Metacharacter m = METACHARACTERS.at(transformStdExpression(symbol));
        if(m.type == 0 || m.type == 2 || (m.type==1 && (m.position == 1 || m.e == "#" || m.e == "-")))
        {
            //如果输入的是小数点,则在其前面添加小数点
            if(symbol == ".")
            {
                inputText->setText(QString("0."));
            }
            else
            {
                inputText->setText(pushButton->text());
            }
        }
        else if(m.type == 1)
        {
            inputText->setText(Ans + pushButton->text());
        }
        historySize.clear();    //清空上次输入的历史记录
        calcFinished=false; //表示正在输入过程中
    }
    historySize.push(pushButton->text().size());    //记录输入的操作词大小
}

QString Widget::cal(QString s)
{
    QString temp;
    expression = new Expression(transformStdExpression(s));
    try
    {
        temp=QString::fromStdString(expression->getResult());
    }catch(runtime_error e){
        QMessageBox messagebox(QMessageBox::Warning,"错误",QString::fromStdString(e.what()));
        messagebox.exec();
        temp = "Error";
    }

    calcFinished = true;
    delete expression;
    return temp;
}

void Widget::onEqualClicked()  //等于按钮按下
{
    QString temp;
    temp=cal(inputText->text());
    if(temp=="Error")   //如果计算出错
    {
        resultText->setText(tr("Error"));
        Ans = "0";
        return;
    }

    /*
     * 由于返回值为double转换的QString,字符串小数位会有一串0,需要去除,并在小数位全为0时去除小数点
     */
    while(temp.right(1)=="0")
        temp=temp.left(temp.size()-1);
    if(temp.right(1)==".")
        temp=temp.left(temp.size()-1);
    resultText->setText(temp);
    /*
     * 如果计算结果为负数,为Ans加上括号便于下次计算使用
     */
    if(temp.at(0) == '-')
        Ans=QString("%1%2%3").arg("(").arg(temp).arg(")");
    else
        Ans = temp;

}
void Widget::onBackspaceClicked()  //删除按钮按下
{
    QString result=inputText->text();
    calcFinished = false;   //计算完成时若按下删除键,重新将计算完成标记置为正在输入中
    if(result.size()==1)    //输入框只剩一个字符
    {
        historySize.clear();
        inputText->setText("0");
        calcFinished = true;
    }
    else
    {
        int length = historySize.empty() ? 1:historySize.pop(); //兼容手动输入字符情况
        inputText->setText(result.left(result.size()-length));
    }
}
void Widget::onClearClicked() //清空按钮按下
{
    inputText->setText("0");
    historySize.clear();
    calcFinished=true;
}















Widget::~Widget()
{
}

