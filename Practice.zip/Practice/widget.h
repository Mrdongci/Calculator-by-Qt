#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QVector>
#include"metaCharacter.h"
#include<QLineEdit>
#include<QGridLayout>
#include<QLabel>
#include<QPushButton>
#include<QHBoxLayout>
#include<QStackedWidget>
#include<QComboBox>
#include "mypushbutton.h"
#include<QStack>
#include "Expression.h"
//按钮布局
const QVector<QVector<string>> BUTTONS{
    {"","","","","","",""},
    {MOD_PERCENT, CE, "", ""},
    {RECIPROCAL_VALUE, POW_TWO, EXTRACT_ROOT_TWO,DIVIDE},
    {SEVEN, EIGHT, NINE, MULTIPLY},
    {FOUR, FIVE, SIX, MINUS},
    {ONE, TWO, THREE, ADD},
    {SYMBOL, ZERO, POINT, ""}};

const QVector<string> FUNCTION_BUTTONS{MC,MR,M_ADD,M_MINUS,MS,M_POW};



class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    QString cal(QString s); //计算,传入表达式s,返回表达式值
      Expression *expression; //表达式计算对象
private:
    QWidget *centralWidget;



    QGridLayout *buttonsLayout;//存放数字按钮及简单按钮
    QGridLayout *mainLayout;

    QHBoxLayout *hLayout;//用来装功能键

    QLineEdit *inputText;   //表达式输入框
    QLabel *equalLabel; //等于号
    QLineEdit *resultText;  //计算结果显示框

    //功能键的显示
    QPushButton *Equal;
    QPushButton *C_Button;
    QPushButton *BackSpace;




    QVector<QPushButton *>buttons;

    QStackedWidget *stackedWidget;

    QComboBox *comboBox;//功能切换按钮
    QLabel *label;
    bool calcFinished = true;   //计算已完成状态标记(与正在输入表达式状态对应)
    QStack<int> historySize;//
    // QStack<int> historySize;
    QString Ans = "0";  //保存上次计算结果
    /*
 * 将表达式中特殊字符转换为规范的计算字符
 * 本程序转换规则有:
 * 显示字符 计算字符
 *    ×     *
 *    ÷     /
 *    √     #
 *    °     `
 */
    string transformStdExpression(QString expression);

private slots:
    void setInputText(MyPushButton *pushButton);  //按钮按下时设置输入框,参数为按钮指针

    //功能键的功能实现函数，无返回值，无参数，EQUAL特殊
    void onEqualClicked();  //等于按钮按下
    void onBackspaceClicked();  //删除按钮按下
    void onClearClicked();  //清空按钮按下


};
#endif // WIDGET_H
