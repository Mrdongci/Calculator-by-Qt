/**
  * QPushButton子类,捕获原不带参数的clicked信号并重新发射clicked(PushButton*)信号,
  * 便于槽函数得知发射信号按钮.
  */
#ifndef MYPUSHBUTTON_H
#define MYPUSHBUTTON_H
#include <QPushButton>

class MyPushButton : public QPushButton
{
    Q_OBJECT
public:
    MyPushButton(const QString &text, QWidget *parent = 0);
    /*
     * 不允许拷贝和赋值
     */
    MyPushButton(const MyPushButton&) = delete;
    MyPushButton& operator=(const MyPushButton&) = delete;

signals:
    void clicked(MyPushButton *MyPushButton);

private slots:
    void onClicked();
};

#endif // PUSHBUTTON_H
